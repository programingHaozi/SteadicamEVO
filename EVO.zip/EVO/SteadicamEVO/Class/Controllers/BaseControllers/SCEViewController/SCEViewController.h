//
//  SCEViewController.h
//  SteadicamEVO
//
//  Created by Chen Hao 陈浩 on 16/3/30.
//  Copyright © 2016年 haozi. All rights reserved.
//

/**
 *  SteadicamEVO 控制器基类
 */
@interface SCEViewController : TFViewController

@property (nonatomic, strong) UINavigationBar *customNavigationBar;

@end
