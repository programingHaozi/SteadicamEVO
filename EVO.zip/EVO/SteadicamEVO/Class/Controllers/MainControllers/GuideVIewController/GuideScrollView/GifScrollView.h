//
//  GifScrollView.h
//  SteadicamEVO
//
//  Created by Chen Hao 陈浩 on 16/4/19.
//  Copyright © 2016年 haozi. All rights reserved.
//

#import <TFScrollView.h>

@interface GifScrollView : UIScrollView

@property (nonatomic, strong) NSArray *dataArray;

@property (nonatomic, assign) BOOL showChoose;

@end
