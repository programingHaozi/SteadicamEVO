//
//  AppDelegate.h
//  SteadicamEVO
//
//  Created by 耗子 on 16/3/6.
//  Copyright © 2016年 haozi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

