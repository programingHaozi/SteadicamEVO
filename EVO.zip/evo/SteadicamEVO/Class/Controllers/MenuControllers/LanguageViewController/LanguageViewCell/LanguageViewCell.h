//
//  LanguageViewCell.h
//  SteadicamEVO
//
//  Created by Chen Hao 陈浩 on 16/4/6.
//  Copyright © 2016年 haozi. All rights reserved.
//

#import "MenuViewCell.h"

@interface LanguageViewCell : MenuViewCell

@property (nonatomic, assign) BOOL selectLanguage;

@end
