//
//  VersionViewModel.m
//  SteadicamEVO
//
//  Created by Chen Hao 陈浩 on 16/6/30.
//  Copyright © 2016年 haozi. All rights reserved.
//

#import "VersionViewModel.h"

@implementation VersionViewModel

-(NSString *)title
{
    return @"Version";
}

@end
