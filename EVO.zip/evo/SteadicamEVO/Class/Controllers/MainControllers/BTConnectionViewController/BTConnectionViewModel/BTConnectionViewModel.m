//
//  BTConnectionViewModel.m
//  SteadicamEVO
//
//  Created by Chen Hao 陈浩 on 16/6/3.
//  Copyright © 2016年 haozi. All rights reserved.
//

#import "BTConnectionViewModel.h"

@implementation BTConnectionViewModel


-(NSString *)title
{
    return @"BT Connection";
}


@end
