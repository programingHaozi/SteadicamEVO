//
//  IntroductionViewCollectionCell.h
//  SteadicamEVO
//
//  Created by 耗子 on 16/4/5.
//  Copyright © 2016年 haozi. All rights reserved.
//

@interface IntroductionViewCollectionCell : TFCollectionViewCell

@property (nonatomic, strong) NSString *gitPath;

@end
