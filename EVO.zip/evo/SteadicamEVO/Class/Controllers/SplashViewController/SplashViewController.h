//
//  SplashViewController.h
//  Orange
//
//  Created by limingchen on 14/12/25.
//  Copyright (c) 2014年 Chexiang. All rights reserved.
//

/**
 *  引导页面
 */
@interface SplashViewController : TFViewController <UIScrollViewDelegate>

@end
