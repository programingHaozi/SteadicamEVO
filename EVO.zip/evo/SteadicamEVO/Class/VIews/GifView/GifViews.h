//
//  GifViews.h
//  SteadicamEVO
//
//  Created by 耗子 on 16/4/5.
//  Copyright © 2016年 haozi. All rights reserved.
//

@interface GifViews : TFView

@property (nonatomic, strong) NSString *moviePath;

@end
