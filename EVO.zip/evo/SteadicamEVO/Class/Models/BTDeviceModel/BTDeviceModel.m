//
//  BTDeviceModel.m
//  SteadicamEVO
//
//  Created by Chen Hao 陈浩 on 16/3/15.
//  Copyright © 2016年 haozi. All rights reserved.
//

#import "BTDeviceModel.h"

@implementation BTDeviceModel

@end
