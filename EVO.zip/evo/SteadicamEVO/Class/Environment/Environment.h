//
//  Environment.h
//  SteadicamEVO
//
//  Created by Chen Hao 陈浩 on 16/4/5.
//  Copyright © 2016年 haozi. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifndef Environment_h
#define Environment_h

#define DefaultDarkColor HEXCOLOR(0x2d2e2e, 1)


#endif /* Environment_h */
